# Author: Darren Colby
# Date: 7/10/2021
# Purpose: To examine the fragmentation of cartels and militias after
# El Chapo's capture

# Libraries ---------------------------------------------------------------

library(blockmodeling)
library(tidyverse)
library(ggraph)
library(igraph)
library(ggthemes)
library(patchwork)
library(texreg)
library(RSiena)

# Load the data -----------------------------------------------------------

drugnet <- read_csv("output/drugnet.csv")

edge_df <- drugnet %>% 
   select(sideA, sideB, weight)

combined_graph <- graph_from_data_frame(edge_df)

combined_matrix <- as.matrix(as_adjacency_matrix(combined_graph))

main_graph <- edge_df %>% 
   distinct(sideA, sideB) %>% 
   graph_from_data_frame()

# Create roles for each actor ---------------------------------------------

# Loop through each number of equivalence groups and find the mean error
block_errors <- map(seq(2, 10, 1), function(k){
   mean(optRandomParC(M = combined_matrix, k = k, rep = 10, approaches = "ss",
                 blocks = "com", seed = 28)$err)}) %>% 
   unlist()

# Plot the structural equivalence solutions -------------------------------

# Create a dataframe from the blockmodels
bind_cols(block_errors, seq(2, 10, 1)) %>% 
   rename("mean_error" = ...1, "groups" = ...2) %>% 
   
   # Plot it
   ggplot(aes(x = groups,
           y = mean_error)) + 
   geom_vline(aes(xintercept = 7),
              linetype = "dashed",
              color = "gray") + 
   geom_hline(aes(yintercept = 56698.39),
              linetype = "dashed",
              color = "gray") + 
   geom_line() + 
   geom_point() + 
   scale_x_continuous(breaks = seq(2, 10, 1),
                      labels = c("2", "3", "4", "5", "6", "Best solution", 
                                 "8", "9", "10")) + 
   labs(x = "Groups",
        y = "Mean error",
        caption = "Note: 10 iterations were used for each number of partitions") + 
   theme_few()

ggsave("figures/figureA1.tiff", width = 6.5, height = 4, dpi = 1000)

# Add structural equivalence group attribute ------------------------------

# Create a 7 block solution
blocks <- optRandomParC(M = combined_matrix, 
                        k = 7,  
                        rep = 100,  
                        approaches = "ss", 
                        blocks = "com",  
                        seed = 42)

# Assign actors to blocks
V(main_graph)$role <- blocks$best$best1$clu

# Ad attribute for militia status -----------------------------------------

militias <- c("malinaltepec communal militia (mexico)", "chamula militia", 
              "san pablo cuatro venados communal militia (mexico)", 
              "dzan communal militia (mexico)", 
              "el pinar communal militia (mexico)", 
              "loma de la cruz communal militia (mexico)", 
              "molinos los arcos communal militia (mexico)", 
              "el carrizal de bravo communal militia (mexico)", 
              "huahua communal militia (mexico)", "tlacotepec communal militia (mexico)", 
              "maya indigenous militia (mexico)", "mixe indigenous militia (mexico)", 
              "san agustin oapan communal militia (mexico)", 
              "santa isabel de la reforma communal militia (mexico)", 
              "aldama indigenous militia (mexico)", 
              "san mateo yucutindoo communal militia (mexico)", 
              "apetlanca communal militia (mexico)", "rio santiago communal militia (mexico)",
              "yautepec communal militia (mexico)", "upoeg self defense group", 
              "faction of front for security and development vigilante group", 
              "totolapan self-defense force", "autodefensas unidas de michoacan", 
              "alacatlatzala communal militia (mexico)", 
              "chocomanatlan communal militia (mexico)", 
              "coahuayutla de guerrero communal militia (mexico)", 
              "cotija de la paz communal militia (mexico)", 
              "cuilapam de guerrero communal militia (mexico)", 
              "el cipresal communal militia (mexico)", 
              "el nith communal militia (mexico)", 
              "ezln: zapatista army of national liberation", 
              "leonardo bravo communal militia (mexico)", 
              "los reyes communal militia (mexico)", 
              "san cristobal de las casas communal militia (mexico)", 
              "san miguel tecuiciapan communal militia (mexico)", 
              "santa maria nativitas coatlan communal militia (mexico)", 
              "santa martha indigenous militia (mexico)", 
              "santiago amoltepec communal militia (mexico)", 
              "santiago miltepec communal militia (mexico)", 
              "santo reyes zochiquilazala communal militia (mexico)", 
              "tangancicuaro communal militia (mexico)", 
              "tenquizolco communal militia (mexico)", 
              "tepalcatepec communal militia (mexico)", 
              "tinguindin communal militia (mexico)", "tocumbo communal militia (mexico)", 
              "villa morelos communal militia (mexico)", 
              "villa victoria communal militia (mexico)", 
              "xochiltepec communal militia (mexico)",
              "rival faction of front for security and development vigilante group")

# Assign militia status to nodes
V(main_graph)$militia <- ifelse(V(combined_graph)$name %in% militias, 1, 0)

# Assign aggressiveness attribute -----------------------------------------

# Convert the graph to a dataframe
temp_vector <- as_data_frame(main_graph) %>% 
   as_tibble() %>% 
   select(from) %>% 
   
   # Merge the vertices with the the aggression data for sending actors
   left_join(drugnet %>% 
                select(sideA, agression) %>% 
                distinct(), 
             by = c("from" = "sideA")) %>% 
   distinct(from, agression) %>% 
   
   # Add the sideB actors to the dataframe. Using a full join will only add rows
   # for actors not already in the dataframe
   full_join(drugnet %>% 
                select(sideB, agression) %>% 
                distinct(),
             by = c("from" = "sideB")) %>% 
   select(-agression.y) %>% 
   rename("agression" = agression.x) %>% 
   distinct(from, agression) %>% 
   select(agression) %>% 
   
   # Codes actors that never directed an attack as having an aggression of 0
   mutate(agression = ifelse(is.na(agression), 0, agression)) %>% 
   ungroup() %>% 
   pull()

# Assign aggression scores to vertices
V(main_graph)$aggression <- temp_vector 

# Code subfaction status --------------------------------------------------

subfaction <- vector(length = 151, mode = "numeric")

# The indices of groups that are subfactions
subfaction[c(8, 72, 74, 75, 77:79, 113, 134, 136:138, 142:146, 148, 149)] <- 1
V(main_graph)$subfaction <- subfaction

# Create graphs for each time period --------------------------------------

# Create a vector of periods in which each tie existed
period <- drugnet %>% 
   mutate(period = ifelse(year < 2017, 1, 2)) %>% 
   group_by(period, sideA, sideB) %>% 
   ungroup() %>% 
   distinct(sideA, sideB, period) %>% 
   group_by(sideA, sideB) %>% 
   summarise(period = max(period)) %>% 
   ungroup() %>% 
   pull(period)

# Add a year attribute to the combined graph
E(main_graph)$period <- period

# Split into two graphs
pre_arrest_graph <- subgraph.edges(main_graph, 
                                   E(main_graph)[E(main_graph)$period < 2])

post_arrest_graph <- subgraph.edges(main_graph, 
                                     E(main_graph)[E(main_graph)$period > 1])

# Plot the graphs before and after El Chapo's arrest ----------------------


# Function to plot networks
# @Params: network, the network to plot; subtitle, a subtitle; colors, a vector
# of colors; legend_position; the position of the legend
# @Returns: A ggraph/ggplot object
plot_network <- function(network, subtitle, colors, legend_position = "right"){
   
   return(ggraph(network,
                 layout = "nicely") +
             geom_edge_link(arrow = arrow(length = unit(2, "mm")),
                            end_cap = circle(1, "mm"),
                            color = "gray30") + 
             geom_node_point(aes(color = as.factor(role)),
                             size = 2) + 
             labs(subtitle = subtitle,
                  color = "Role") + 
             scale_color_manual(values = colors) + 
             theme_graph() + 
             theme(plot.subtitle = element_text(hjust = 0.5),
                   legend.position = legend_position))
}


p1 <- plot_network(pre_arrest_graph, "Pre-arrest", 
                   c("blue4", "red4", "olivedrab4", 
                     "darkorchid4", "darkcyan", "gray10"),
                   "none")

p2 <- plot_network(main_graph, "Post-arrest",
                   c("blue4", "red4", "olivedrab4", "darkorchid4",
                   "darkcyan", "chocolate4", "gray10"))

p1 + p2 + plot_layout(guides = "collect")

ggsave("figures/figure1.tiff", width = 6.5, height = 4, dpi = 600)

# Plot degree distribution ------------------------------------------------


# Function for plotting the degree distribution of a network
# @Params: graph, an igraph object; mode, in for in-degree and out for 
# out-degree; subtitle, a subtitle for the plot; xlab, a label for the x-axis; 
# limits, used to expand the y-axis
# @Returns: A ggplot object showing the degree distribution of a network
plot_degree_distribution <- function(graph, mode, subtitle, xlab, limits){
   
   return(as_tibble(degree(graph, mode = mode)) %>% 
             rename("degree" = value) %>% 
             group_by(degree) %>% 
             summarise(count = n()) %>% 
             ungroup() %>% 
             ggplot(aes(x = as.factor(degree),
                        y = count)) +  
             scale_y_continuous(expand = c(0, 0), 
                                limits = limits) + 
             scale_x_discrete(expand = c(0, 0.5)) + 
             geom_col() + 
             labs(subtitle = subtitle,
                  x = xlab,
                  y = "Count") + 
             geom_text(aes(label = count),
                       vjust = -0.5) + 
             theme_few())
}

p3 <- plot_degree_distribution(pre_arrest_graph, "in", "Before", "In-degree", 
                               c(0, 25))
p4 <- plot_degree_distribution(pre_arrest_graph, "out", NULL, "Out-degree", 
                               c(0, 20))
p5 <- plot_degree_distribution(main_graph, "in", "After", "In-degree", c(0, 105))
p6 <- plot_degree_distribution(main_graph, "out", NULL, "Out-degree", c(0, 85))

p3 + p5 +  p4 + p6

ggsave("figures/figure2.tiff", width = 6.2, height = 3.7, dpi = 300)

# Prepare the data for SAOM estimation ------------------------------------

# Make a graph for the first time period
t0_network <- main_graph %>% 
   delete_edges(as.vector(E(post_arrest_graph)))

# Make a list for joiner nodes
joiner_nodes <- as_tibble(as.vector(V(t0_network)$name)) %>% 
                   mutate(node = row_number()) %>% 
                   ungroup() %>% 
                   relocate(node) %>% 
                   filter(!(value %in% as.vector(V(pre_arrest_graph)$name))) %>% 
                   pull(node)

# Make a list for all nodes and code them as being present in both periods
joiners <- rep(list(c(1, 2)), 151)

# Update periods for nodes that were only present in the second period
for (i in seq_along(joiners)){
   
   # Check to see if a node was a joiner in the second period
   if (i %in% joiner_nodes){
      
      # Recode the list to show joiners only in period 2
      joiners[[i]][1] <- 2
      
   }
   
}

# Creates an RSiena object for joiners
joiners <- sienaCompositionChange(joiners)

# Create a dependent variable
dv <- sienaDependent(array(c(as.matrix(as_adjacency_matrix(t0_network)), 
                             as.matrix(as_adjacency_matrix(main_graph))), 
                           dim=c(151, 151, 2)))

# Create constant covariates objects
role_var <- coCovar(as.vector(V(main_graph)$role))
militia_var <- coCovar(as.vector(V(main_graph)$militia))
aggression_var <- coCovar(as.vector(V(main_graph)$aggression))
subfaction_var <- coCovar(as.vector(V(main_graph)$subfaction))

# Run models with different effects ---------------------------------------


# Function to estimate a stochastic actor oriented model
# @Params: effect, the effect to estimate; seed, the seed to set the machine to
# @Returns: A sienaFit object
estimate_saom <- function(effect, seed){
   
   effect <- deparse(substitute(effect))
   
   # Create the basic data
   data <- sienaDataCreate(dv, aggression_var, subfaction_var, militia_var, 
                           role_var, joiners)
   
   # Effects for rate, reciprocity, and out-degree
   effects <- getEffects(data)
   
   # Effects for in-degree popularity, in-degree activity, out-degree popularity,
   # and balance. These reflect preferential attachment and similarity for outgoing 
   # ties between actors
   if (effect == "Jout") effects <- includeEffects(effects, Jout)
   if (effect == "inPop") effects <- includeEffects(effects, inPop)
   if (effect == "outInAss") effects <- includeEffects(effects, outInAss)
   if (effect == "transTrip1") effects <- includeEffects(effects, transTrip1)
   
   # Effects for homophily
   effects <- includeEffects(effects, sameX, interaction1 = "aggression_var")
   effects <- includeEffects(effects, sameX, interaction1 = "subfaction_var")
   effects <- includeEffects(effects, sameX, interaction1 = "militia_var")
   effects <- includeEffects(effects, sameX, interaction1 = "role_var")
   
   # Define algorithm and get results
   algorithm <- sienaAlgorithmCreate(projname = "output", seed = seed, n3 = 3000)
   results <- siena07(algorithm, data = data, effects = effects, returnDeps = TRUE)
   
   # Check for convergence
   if (max(results$tstat > 0.25) | abs(results$tconv.max) > 0.1){
      
      results <- siena07(algorithm, data = data, effects = effects, 
                         returnDeps = TRUE, prevAns = results)
      
   }
   
   return(results)
   
}


m1_results <- estimate_saom(Jout, 100)
m2_results <- estimate_saom(inPop, 200)
m3_results <- estimate_saom(outInAss, 300)
m4_results <- estimate_saom(transTrip1, 400)

# Plot the results --------------------------------------------------------


# Function to plot the difference of relative importance scores of effects
# between the first and second networks.
# @Params: results; a sienaFit object; effect, the name of the effect of
# interest; title, a title for the plot; subtitle, a subtitle for the plot
# @Returns: A ggplot2 object
plot_importance <- function(results, effect, subtitle){
   
   # Creates a sienaData object
   data <- sienaDataCreate(dv, aggression_var, subfaction_var, militia_var, 
                           role_var, joiners)
   
   # Vectors for the mean relative importance for each effect in both periods
   before <- sienaRI(data, results)[[4]][1] %>% unlist()
   after <- sienaRI(data, results)[[4]][2] %>% unlist()
   
   # Creates a vector for statistical significance
   signif <- plotreg(results)[[1]][10][-1, ] %>% unlist()
   
   # A vector of effect names
   effect_names <- plotreg(results)[[1]][1][-1, ] %>% unlist()
   
   # Creates a tibble of effect names, difference in relative importance and
   # statistical significance
   before_after_df <- bind_cols(effect_names, before, after, signif) %>% 
      rename(effect = "...1", before = "...2", after = "...3", signif = "...4") %>% 
      mutate(dif = after - before) %>% 
      ungroup()
   
   plot <- ggplot(data = before_after_df) + 
      geom_point(aes(x = before,
                     y = effect,
                     color = signif)) + 
      geom_segment(aes(x = before,
                       xend = after,
                       y = effect,
                       yend = effect,
                       color = signif),
                   arrow = arrow(length = unit(2, "mm"), 
                                 type = "closed")) + 
      scale_y_discrete(labels = c("Role\nsimilarity", "Militia\nsimilarity",
                                  "Subfaction\nsimilarity", 
                                  "Aggression\nsimilarity", 
                                  effect, "Reciprocity", 
                                  "Rate")) +
      
      # Statistically significant variables are red
      scale_color_manual(values = c("black", "red")) +
      labs(subtitle = subtitle,
           x = "Mean relative importance",
           y = NULL) +  
      geom_text(aes(x = (before + after)/2,
                    y = effect,
                    label = round(dif, 3)),
                vjust = -0.5,
                hjust = 0.5) + 
      theme_few() + 
      theme(legend.position = "none")
   
   return(plot)
   
}


plot_importance(m1_results, effect = "Out-degree\nJaccard similarity", 
                subtitle = "Alliance degradation")
ggsave("figures/figure3.tiff", width = 6.5, height = 4, dpi = 1000)

p7 <- plot_importance(m2_results, effect = "In-degree\npopularity", 
                      subtitle = "Preferential attachment") + 
   expand_limits(x = c(0, 0.6))
p8 <- plot_importance(m3_results, effect = "Out-in-degree\nassortativity", 
                      subtitle = "Strong preying on the weak") + 
   expand_limits(x = c(0, 0.85))
p7|p8
ggsave("figures/figure4.tiff", width = 6.5, height = 4, dpi = 1000)

plot_importance(m4_results, effect = "Transitive closure", 
                subtitle = "Clustering")
ggsave("figures/figure5.tiff", width = 6.5, height = 4, dpi = 1000)
